function [ck,wk]=get_fs_coeff2(x,dt,T0,N)

syms t;

x_length = length(x);

for k=-N:1:N
    ck(k+N+1)=0;
    wk(k+N+1)=k;
    for m=1:x_length
        ck(k+N+1) = ck(k+N+1)+(1/T0)*int(x(m)*exp(-1j*2*pi*k*t/T0), dt(m), dt(m+1));
    end
end