n=input('how many points?...');
figure();
[x,y]=ginput(n);

N=input('how many coefficients?...');
for i=1:length(x)
    xn=x(i);
end
To=5;
ft=fft(x,N);
figure;
subplot(3,1,1);
stem(x,y); grid on;
subplot(3,1,2);
stem(ft); grid on;
synth_sig=ifft(ft,n);
subplot(3,1,3);
stem(synth_sig); grid on;
