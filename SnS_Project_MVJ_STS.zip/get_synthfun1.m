function xt = get_synthfun1(ck,k)
syms t;
xt=0;
for m=1:1:length(k)
    xt=xt+ck(m)*exp(1j*k(m)*t);
end
end
    
    
